namespace Worker.Data
{
    public interface IVoteData
    {
        void Set(string voterId, string vote);
    }
}